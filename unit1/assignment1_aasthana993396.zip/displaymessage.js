// External javascript file.
document.write("JavaScript... I'm loving it!");