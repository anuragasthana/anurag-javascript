var num1 = 9; 
var num2 = 7;
if (num1 < num2) {
    window.alert("True");
}
else {
    window.alert("False");
}
