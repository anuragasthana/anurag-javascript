
//using for loop
/* for(var text=1;text<=15;text++) {
 document.write(text+". This is getting way too repetitive.<BR>");
 }

document.write("<BR>"); */

//using while loop
var text = 1;
while (text <= 15) {
    document.write(text + ". This is getting way too repetitive.<BR>");
    text++;
}
