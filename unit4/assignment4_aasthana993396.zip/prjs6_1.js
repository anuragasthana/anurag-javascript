var thesport = "Golf";
var myfood = "Pizza";
if (thesport == "Football") {
    window.alert("Cool Sport");
}
else {
    window.alert("That sport might be cool");
}
if (myfood == "Pizza") {
    window.alert("My favourite food!");
}
else {
    window.alert("That food sounds OK I guess.");
}
