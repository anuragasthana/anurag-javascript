var cars = new Array();
cars["cool"] = "Mustang";
cars["small"] = "Bug";
cars["long"] = "Station Wagon";

document.write("The cool one is the " + cars["cool"] + ".<br>");
document.write("The small one is the " + cars["small"] + ".<br>");
document.write("The long one is the " + cars["long"] + ".<br>");
