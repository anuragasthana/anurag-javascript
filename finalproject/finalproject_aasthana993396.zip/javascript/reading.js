/*  What does this file have ?
	1. document method getElementById
	2. innerhtml 
*/


row_1= {book1:"Eragon",book2:"Eldest",book3:"Brisingr",book4:"Inheritance",book5:"Harry Potter and The Sorcerer's Stone"}

var bk_1= document.getElementById("bk1")
var bk_2= document.getElementById("bk2")
var bk_3= document.getElementById("bk3")
var bk_4= document.getElementById("bk4")
var bk_5= document.getElementById("bk5")

bk_1.innerHTML= row_1.book1
bk_2.innerHTML= row_1.book2
bk_3.innerHTML= row_1.book3
bk_4.innerHTML= row_1.book4
bk_5.innerHTML= row_1.book5 


row_2= {book1:"Harry Potter and The Chamber of Secrets",book2:"Harry Potter and The Prisoner of Azkaban",book3:"Harry Potter and The Goblet of Fire",book4:"Harry Potter and The Order of The Phoenix",book5:"Harry Potter and The Half Blood Prince"}

var bk_6= document.getElementById("bk6")
var bk_7= document.getElementById("bk7")
var bk_8= document.getElementById("bk8")
var bk_9= document.getElementById("bk9")
var bk_10= document.getElementById("bk10")

bk_6.innerHTML= row_2.book1
bk_7.innerHTML= row_2.book2
bk_8.innerHTML= row_2.book3
bk_9.innerHTML= row_2.book4
bk_10.innerHTML= row_2.book5 

 

row_3= {book1:"Harry Potter and The Deathly Hallows",book2:"Harry Potter: The Tales of Beedle the Bard",book3:"The Mysterious Benedict Society",book4:"The Mysterious Benedict Society and the Perilous Journey",book5:"The Mysterious Benedict Society and The Prisoner's Dilemma"}

var bk_11= document.getElementById("bk11")
var bk_12= document.getElementById("bk12")
var bk_13= document.getElementById("bk13")
var bk_14= document.getElementById("bk14")
var bk_15= document.getElementById("bk15")

bk_11.innerHTML= row_3.book1
bk_12.innerHTML= row_3.book2
bk_13.innerHTML= row_3.book3
bk_14.innerHTML= row_3.book4
bk_15.innerHTML= row_3.book5

row_4= {book1:"The Mysterious Benedict Society: Mr. Benedict's Book of Perplexing Puzzles, Elusive Enigmas, and Curious Conundrums",book2:"The Extraordinary Education of Nicholas Benedict",book3:"Percy Jackson and The Olympians: The Lightning Thief",book4:"Percy Jackson and The Olympians: The Sea of Monsters",book5:"Percy Jackson and The Olympians: The Titan's Curse"}

var bk_16= document.getElementById("bk16")
var bk_17= document.getElementById("bk17")
var bk_18= document.getElementById("bk18")
var bk_19= document.getElementById("bk19")
var bk_20= document.getElementById("bk20")

bk_16.innerHTML= row_4.book1
bk_17.innerHTML= row_4.book2
bk_18.innerHTML= row_4.book3
bk_19.innerHTML= row_4.book4
bk_20.innerHTML= row_4.book5

row_5= {book1:"Percy Jackson and The Olympians: The Battle of The Labyrinth",book2:"Percy Jackson and The Olympians: The Last Olympian",book3:"The Heroes of Olympus: The Lost Hero",book4:"The Heroes of Olympus: The Son of Neptune",book5:"The Heroes of Olympus: The Mark of Athena"}

var bk_21= document.getElementById("bk21")
var bk_22= document.getElementById("bk22")
var bk_23= document.getElementById("bk23")
var bk_24= document.getElementById("bk24")
var bk_25= document.getElementById("bk25")

bk_21.innerHTML= row_5.book1
bk_22.innerHTML= row_5.book2
bk_23.innerHTML= row_5.book3
bk_24.innerHTML= row_5.book4
bk_25.innerHTML= row_5.book5

row_6= {book1:"The Chronicles of Kane: The Red Pyramid",book2:"The Chronicles of Kane: The Throne Of Fire",book3:"The Chronicles of Kane: The Serpent's Shadow",book4:"Diary of a Wimpy Kid",book5:"Diary of a Wimpy Kid: Rodrick Rules"}

var bk_26= document.getElementById("bk26")
var bk_27= document.getElementById("bk27")
var bk_28= document.getElementById("bk28")
var bk_29= document.getElementById("bk29")
var bk_30= document.getElementById("bk30")

bk_26.innerHTML= row_6.book1
bk_27.innerHTML= row_6.book2
bk_28.innerHTML= row_6.book3
bk_29.innerHTML= row_6.book4
bk_30.innerHTML= row_6.book5

row_7= {book1:"Diary of a Wimpy Kid: The Last Straw",book2:"Diary of a Wimpy Kid: Dog Days",book3:"Diary of a Wimpy Kid: The Ugly Truth",book4:"Diary of a Wimpy Kid: Cabin Fever",book5:"Diary of a Wimpy Kid: The Third Wheel"}

var bk_31= document.getElementById("bk31")
var bk_32= document.getElementById("bk32")
var bk_33= document.getElementById("bk33")
var bk_34= document.getElementById("bk34")
var bk_35= document.getElementById("bk35")

bk_31.innerHTML= row_7.book1
bk_32.innerHTML= row_7.book2
bk_33.innerHTML= row_7.book3
bk_34.innerHTML= row_7.book4
bk_35.innerHTML= row_7.book5


row_8= {book1:"The Wonderful Wizard of Oz",book2:"Dorothy and The Wizard in Oz",book3:"The Emerald City of Oz",book4:"Tik-Tok of Oz",book5:"Rinkitink in Oz"}

var bk_36= document.getElementById("bk36")
var bk_37= document.getElementById("bk37")
var bk_38= document.getElementById("bk38")
var bk_39= document.getElementById("bk39")
var bk_40= document.getElementById("bk40")

bk_36.innerHTML= row_8.book1
bk_37.innerHTML= row_8.book2
bk_38.innerHTML= row_8.book3
bk_39.innerHTML= row_8.book4
bk_40.innerHTML= row_8.book5


row_9= {book1:"The Golden Goblet",book2:"The Mysterious Island",book3:"The Swiss Family Robinson",book4:"Treasure Island",book5:"The Wind in the Willows"}

var bk_41= document.getElementById("bk41")
var bk_42= document.getElementById("bk42")
var bk_43= document.getElementById("bk43")
var bk_44= document.getElementById("bk44")
var bk_45= document.getElementById("bk45")

bk_41.innerHTML= row_9.book1
bk_42.innerHTML= row_9.book2
bk_43.innerHTML= row_9.book3
bk_44.innerHTML= row_9.book4
bk_45.innerHTML= row_9.book5


row_10= {book1:"Around the World in 80 Days",book2:"A Short History of Nearly Everything",book3:"After Gandhi: One Hundred Years of Non-violent Resistance",book4:"Despereaux",book5:"The BFG"}

var bk_46= document.getElementById("bk46")
var bk_47= document.getElementById("bk47")
var bk_48= document.getElementById("bk48")
var bk_49= document.getElementById("bk49")
var bk_50= document.getElementById("bk50")

bk_46.innerHTML= row_10.book1
bk_47.innerHTML= row_10.book2
bk_48.innerHTML= row_10.book3
bk_49.innerHTML= row_10.book4
bk_50.innerHTML= row_10.book5


row_11= {book1:"The Witches",book2:"Charlie and The Chocolate Factory",book3:"Charlie and The Great Glass Elevator",book4:"Danny the Champion of the World",book5:"James and the Giant Peach"}

var bk_51= document.getElementById("bk51")
var bk_52= document.getElementById("bk52")
var bk_53= document.getElementById("bk53")
var bk_54= document.getElementById("bk54")
var bk_55= document.getElementById("bk55")

bk_51.innerHTML= row_11.book1
bk_52.innerHTML= row_11.book2
bk_53.innerHTML= row_11.book3
bk_54.innerHTML= row_11.book4
bk_55.innerHTML= row_11.book5