//Anurag Asthana
//993396
function button_dynamic(){
	window.alert("I am a dynamic button.");
	window.alert("Thanks for clicking me!");
}

document.getElementById("dynamic_button").onclick=button_dynamic;