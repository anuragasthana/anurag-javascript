function send_alerts(){
    window.alert("Hi there,and welcome to my page!");
    window.alert("Please sign the guest book before you leave!");
    window.alert("Are these alerts annoying you yet? Ha! Ha!");
}

document.getElementById("get_alerts").onclick = send_alerts;
